package com.amigorenta.contratos;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Store {
    static final Locale ES = new Locale("es");
    static final TimeZone TZ = TimeZone.getTimeZone("America/Vancouver");

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("contratos", Context.MODE_PRIVATE); }

    static synchronized List<JSONObject> list(Context c, String k) {
        ArrayList<JSONObject> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString(k, "[]"));
            for (int i = 0; i < a.length(); i++) r.add(a.getJSONObject(i));
        } catch (Exception e) { }
        return r;
    }

    static synchronized void save(Context c, String k, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        sp(c).edit().putString(k, a.toString()).commit();
    }

    static String get(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void putS(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    static void put(JSONObject o, String k, Object v) { try { o.put(k, v); } catch (Exception e) { } }

    static String cap(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(ES) + s.substring(1); }

    static String dateTime(long ms) {
        SimpleDateFormat a = new SimpleDateFormat("EEE d MMM yyyy", ES), b = new SimpleDateFormat("h:mm a", Locale.US);
        a.setTimeZone(TZ);
        b.setTimeZone(TZ);
        return cap(a.format(new Date(ms))) + ", " + b.format(new Date(ms));
    }

    static boolean installed(Context c, String pkg) {
        try { c.getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; }
    }

    static String waPkg(Context c) {
        String pref = get(c, "waApp", "business").equals("business") ? "com.whatsapp.w4b" : "com.whatsapp";
        if (installed(c, pref)) return pref;
        if (installed(c, "com.whatsapp.w4b")) return "com.whatsapp.w4b";
        if (installed(c, "com.whatsapp")) return "com.whatsapp";
        return null;
    }

    static String digits(String phone) {
        String d = phone == null ? "" : phone.replaceAll("[^0-9]", "");
        if (d.length() == 10) d = "1" + d;
        return d;
    }

    static Intent waIntent(Context c, String phone, String text) {
        String url = "https://wa.me/" + digits(phone) + (text == null || text.isEmpty() ? "" : "?text=" + Uri.encode(text));
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        String pkg = waPkg(c);
        if (pkg != null) i.setPackage(pkg);
        return i;
    }

    static void notifyNow(Context c, int code, String title, String text) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("contratos", "Contratos Amigo Renta", NotificationManager.IMPORTANCE_HIGH));
            Intent oi = new Intent(c, MainActivity.class);
            oi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent open = PendingIntent.getActivity(c, 3, oi, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(c, "contratos")
                    .setSmallIcon(android.R.drawable.ic_menu_edit)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build();
            nm.notify(code, n);
        } catch (Exception e) { }
    }
}
