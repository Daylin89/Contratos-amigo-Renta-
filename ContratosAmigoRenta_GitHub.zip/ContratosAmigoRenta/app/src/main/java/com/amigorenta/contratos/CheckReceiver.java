package com.amigorenta.contratos;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class CheckReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) { Sync.schedule(c); return; }
        if (!Net.ready(c) || !Sync.anyPending(c)) return;
        final PendingResult pr = goAsync();
        new Thread(() -> { try { Sync.refresh(c); } finally { pr.finish(); } }).start();
    }
}
