package com.amigorenta.contratos;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** Trae el estado de los contratos, avisa los recién firmados y guarda su PDF. Bloqueante: llamar en segundo plano. */
public class Sync {
    static synchronized String refresh(Context c) {
        if (!Net.ready(c)) return "Falta la dirección del servidor o la clave en Ajustes";
        Net.Res r = Net.request(c, "GET", "/contracts", null, null, null);
        if (r.error != null || r.code != 200) return Net.errorOf(r.code, r.body, r.error);
        try {
            JSONArray a = new JSONObject(Net.text(r.body)).getJSONArray("contracts");
            List<JSONObject> old = Store.list(c, "contracts"), fresh = new ArrayList<>(), newly = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) {
                JSONObject n = a.getJSONObject(i);
                JSONObject o = null;
                for (JSONObject x : old) if (x.optString("id").equals(n.optString("id"))) o = x;
                if (o != null) {
                    Store.put(n, "phone", o.optString("phone"));
                    if (!o.optString("localSigned").isEmpty()) Store.put(n, "localSigned", o.optString("localSigned"));
                    if (!o.optString("status").equals("firmado") && n.optString("status").equals("firmado")) newly.add(n);
                }
                fresh.add(n);
            }
            for (JSONObject n : newly) {
                Uri u = download(c, n);
                if (u != null) Store.put(n, "localSigned", u.toString());
                Store.notifyNow(c, 60000 + Math.abs(n.optString("id").hashCode() % 10000), "✍️ Contrato firmado: " + n.optString("name"), n.optString("title"));
            }
            Store.save(c, "contracts", fresh);
            return null;
        } catch (Exception e) { return "Respuesta inesperada del servidor"; }
    }

    static Uri download(Context c, JSONObject ct) {
        Net.Res r = Net.request(c, "GET", "/contracts/" + ct.optString("id") + "/signed", null, null, null);
        if (r.error != null || r.code != 200 || r.body == null || r.body.length < 5) return null;
        return saveFile(c, ct, r.body);
    }

    static Uri saveFile(Context c, JSONObject ct, byte[] pdf) {
        if (Build.VERSION.SDK_INT < 29) return null;
        try {
            ContentValues cv = new ContentValues();
            String nm = ct.optString("title", "Contrato").replaceAll("[^A-Za-z0-9ÁÉÍÓÚÑáéíóúñ \\-]", "").trim().replace(' ', '_');
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nm + "_FIRMADO.pdf");
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Contratos");
            Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return null;
            try (OutputStream os = c.getContentResolver().openOutputStream(u)) { os.write(pdf); }
            return u;
        } catch (Exception e) { return null; }
    }

    static boolean anyPending(Context c) {
        for (JSONObject o : Store.list(c, "contracts")) if (!o.optString("status").equals("firmado")) return true;
        return false;
    }

    /** Revisa cada ~30 minutos, aunque la app esté cerrada. */
    static void schedule(Context c) {
        PendingIntent pi = PendingIntent.getBroadcast(c, 7, new Intent(c, CheckReceiver.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + AlarmManager.INTERVAL_HALF_HOUR, AlarmManager.INTERVAL_HALF_HOUR, pi);
    }
}
