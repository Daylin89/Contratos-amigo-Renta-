package com.amigorenta.contratos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Copia de seguridad de la app Contratos (los datos de la app; los PDF están en el servidor y en Descargas). */
public class Respaldo {
    static final String DIR = Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Respaldos";

    static String json(Context c) throws Exception {
        JSONObject o = new JSONObject();
        o.put("app", "contratos");
        o.put("fecha", System.currentTimeMillis());
        JSONObject p = new JSONObject();
        for (Map.Entry<String, ?> e : Store.sp(c).getAll().entrySet()) {
            if (e.getKey().equals("deviceKey") || !(e.getValue() instanceof String)) continue; // la clave del servidor no se guarda en la copia
            p.put(e.getKey(), e.getValue());
        }
        o.put("datos", p);
        return o.toString();
    }

    static Uri save(Context c) {
        if (Build.VERSION.SDK_INT < 29) return null;
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "Contratos_respaldo_" + new SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(new Date()) + ".json");
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, DIR);
            Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return null;
            try (OutputStream os = c.getContentResolver().openOutputStream(u)) { os.write(json(c).getBytes(StandardCharsets.UTF_8)); }
            Store.sp(c).edit().putLong("lastBackup", System.currentTimeMillis()).apply();
            return u;
        } catch (Exception e) { return null; }
    }

    /** Una copia automática por semana. */
    static void auto(Context c) {
        long last = Store.sp(c).getLong("lastBackup", 0);
        if (System.currentTimeMillis() - last < 7L * 86400000L) return;
        if (Store.list(c, "contracts").isEmpty()) return;
        save(c);
    }

    static void menu(MainActivity a) {
        long last = Store.sp(a).getLong("lastBackup", 0);
        String[] o = {"📁 Guardar copia ahora (en Descargas)", "☁️ Guardar copia en OneDrive (info@amigorenta.com)", "📤 Enviar copia (correo, WhatsApp, Drive)",
                "♻️ Restaurar desde una copia", "📥 Descargar todos los contratos firmados", "☁️ Subir contratos firmados a OneDrive"};
        new AlertDialog.Builder(a).setTitle("💾 Copia de seguridad")
                .setMessage((last > 0 ? "Última copia: " + Store.dateTime(last) : "Todavía no hay copias") + "\nSe hace sola una vez por semana.")
                .setItems(o, (d, w) -> {
                    if (w == 0) {
                        Uri u = save(a);
                        Toast.makeText(a, u != null ? "Copia guardada en Descargas → Amigo Renta Respaldos ✅" : "No se pudo crear la copia", Toast.LENGTH_LONG).show();
                    } else if (w == 1) {
                        toOneDrive(a, one(save(a)), "application/json");
                    } else if (w == 5) {
                        signedToOneDrive(a);
                    } else if (w == 2) {
                        Uri u = save(a);
                        if (u == null) { Toast.makeText(a, "No se pudo crear la copia", Toast.LENGTH_LONG).show(); return; }
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("application/json");
                        i.putExtra(Intent.EXTRA_STREAM, u);
                        i.putExtra(Intent.EXTRA_SUBJECT, "Copia de seguridad · Contratos Amigo Renta");
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        a.launch(Intent.createChooser(i, "Enviar copia"));
                    } else if (w == 3) {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        try { a.startActivityForResult(i, MainActivity.REQ_RESTORE); } catch (Exception e) { Toast.makeText(a, "No se pudo abrir el selector", Toast.LENGTH_SHORT).show(); }
                    } else downloadAll(a);
                }).show();
    }

    static void restore(MainActivity a, Uri u) {
        try (InputStream is = a.getContentResolver().openInputStream(u)) {
            JSONObject o = new JSONObject(new String(Net.readAll(is), StandardCharsets.UTF_8));
            if (!"contratos".equals(o.optString("app"))) throw new Exception("No es una copia de la app Contratos");
            JSONObject p = o.getJSONObject("datos");
            new AlertDialog.Builder(a).setTitle("¿Restaurar esta copia?")
                    .setMessage("Copia del " + Store.dateTime(o.optLong("fecha")) + ". Reemplaza la lista y los ajustes de este teléfono. La clave del servidor no viene en la copia: después escríbela en Ajustes.")
                    .setPositiveButton("Restaurar", (d, w) -> {
                        SharedPreferences.Editor ed = Store.sp(a).edit();
                        String key = Store.get(a, "deviceKey", "");
                        for (Iterator<String> it = p.keys(); it.hasNext(); ) { String k = it.next(); ed.putString(k, p.optString(k)); }
                        if (!key.isEmpty()) ed.putString("deviceKey", key);
                        ed.commit();
                        Toast.makeText(a, "Copia restaurada ✅", Toast.LENGTH_LONG).show();
                        a.recreate();
                    }).setNegativeButton("Cancelar", null).show();
        } catch (Exception e) {
            Toast.makeText(a, "No se pudo leer la copia: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** Baja a Descargas → Amigo Renta Contratos todos los firmados que todavía no estén en el teléfono. */
    static void downloadAll(MainActivity a) {
        AlertDialog wait = new AlertDialog.Builder(a).setMessage("Descargando contratos firmados…").setCancelable(false).show();
        new Thread(() -> {
            String err = Sync.refresh(a);
            int got = 0, had = 0, fail = 0;
            if (err == null) {
                List<JSONObject> cs = Store.list(a, "contracts");
                for (JSONObject o : cs) {
                    if (!o.optString("status").equals("firmado")) continue;
                    if (!o.optString("localSigned").isEmpty() && exists(a, o.optString("localSigned"))) { had++; continue; }
                    Uri u = Sync.download(a, o);
                    if (u != null) { Store.put(o, "localSigned", u.toString()); got++; } else fail++;
                }
                Store.save(a, "contracts", cs);
            }
            final String msg = err != null ? err : "Descargados: " + got + "\nYa estaban en el teléfono: " + had + (fail > 0 ? "\nNo se pudieron bajar: " + fail : "")
                    + "\n\nEstán en Descargas → Amigo Renta Contratos.";
            a.runOnUiThread(() -> { wait.dismiss(); new AlertDialog.Builder(a).setTitle("📥 Contratos firmados").setMessage(msg).setPositiveButton("OK", null).show(); });
        }).start();
    }

    /** Sube a OneDrive los contratos firmados que están en el teléfono. */
    static void signedToOneDrive(MainActivity a) {
        java.util.ArrayList<Uri> l = new java.util.ArrayList<>();
        int missing = 0;
        for (JSONObject o : Store.list(a, "contracts")) {
            if (!o.optString("status").equals("firmado")) continue;
            String u = o.optString("localSigned");
            if (!u.isEmpty() && exists(a, u)) l.add(Uri.parse(u)); else missing++;
        }
        if (l.isEmpty()) {
            Toast.makeText(a, missing > 0 ? "Primero toca «📥 Descargar todos los contratos firmados»" : "Todavía no hay contratos firmados", Toast.LENGTH_LONG).show();
            return;
        }
        if (missing > 0) Toast.makeText(a, missing + " firmados aún no están en el teléfono (usa «📥 Descargar todos»)", Toast.LENGTH_LONG).show();
        toOneDrive(a, l, "application/pdf");
    }

    static boolean exists(Context c, String uri) {
        try (InputStream is = c.getContentResolver().openInputStream(Uri.parse(uri))) { return is != null; } catch (Exception e) { return false; }
    }

    // ---------- OneDrive (info@amigorenta.com) ----------
    static final String OD = "com.microsoft.skydrive";

    /** Abre la app OneDrive para subir los archivos (en el teléfono debe estar la cuenta info@amigorenta.com). */
    static void toOneDrive(Activity a, java.util.ArrayList<Uri> uris, String mime) {
        if (uris == null || uris.isEmpty()) { Toast.makeText(a, "No hay archivos para subir", Toast.LENGTH_LONG).show(); return; }
        Intent i = new Intent(uris.size() > 1 ? Intent.ACTION_SEND_MULTIPLE : Intent.ACTION_SEND);
        i.setType(mime);
        if (uris.size() > 1) i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        else i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.setPackage(OD);
        try {
            a.startActivity(i);
            Toast.makeText(a, "☁️ En OneDrive elige la carpeta (ej. «Amigo Renta») y toca Subir", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            new AlertDialog.Builder(a).setTitle("☁️ Falta la app OneDrive")
                    .setMessage("Instala OneDrive en este teléfono y entra con la cuenta info@amigorenta.com. Después vuelve a tocar «Guardar en OneDrive».")
                    .setPositiveButton("Instalar OneDrive", (d, w) -> {
                        try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + OD))); }
                        catch (Exception e2) { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + OD))); }
                    }).setNegativeButton("Cancelar", null).show();
        }
    }

    static java.util.ArrayList<Uri> one(Uri u) { java.util.ArrayList<Uri> l = new java.util.ArrayList<>(); if (u != null) l.add(u); return l; }
}
