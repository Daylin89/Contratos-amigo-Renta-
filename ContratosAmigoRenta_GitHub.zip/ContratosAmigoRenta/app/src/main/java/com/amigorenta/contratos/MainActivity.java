package com.amigorenta.contratos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.widget.ImageView;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    static final int PRI = 0xFF0D3B7A, PRI2 = 0xFF1565C0, BG = 0xFFF3F6FB, TXT = 0xFF1A2433,
            MUT = 0xFF6B7585, BRD = 0xFFE1E7EF, RED = 0xFFDC2626, GRN = 0xFF16A34A, ORG = 0xFFEA580C, YEL = 0xFFB45309;
    static final int REQ_PDF = 95, REQ_RESTORE = 96;
    static final int TXT_CAP = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS;

    FrameLayout content;
    LinearLayout header;
    TextView fab;
    final ArrayList<Runnable> stack = new ArrayList<>();
    String cName = "", cEmail = "", cPhone = "", cTitle = "", pendingMail = null;
    byte[] cPdf;
    final List<JSONObject> cFields = new ArrayList<>();
    String mode = "signature";
    int curPage = 0, nPages = 0;
    PdfRenderer renderer;
    ParcelFileDescriptor pfd;
    long lastCheck = 0;
    String filter = "Todos";

    // ============================ ciclo de vida ============================
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout col = vbox();
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        header = hbox();
        header.setBackgroundColor(PRI);
        header.setPadding(dp(16), dp(14), dp(16), dp(14));
        col.addView(header, new LinearLayout.LayoutParams(-1, -2));
        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        fab = tv("", 15, Color.WHITE, true);
        fab.setBackground(round(GRN, 28));
        fab.setPadding(dp(22), dp(14), dp(22), dp(14));
        fab.setElevation(dp(6));
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, dp(16), dp(24));
        root.addView(fab, fl);
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
        Sync.schedule(this);
        Respaldo.auto(this);
        open(Net.ready(this) ? (Runnable) this::home : this::settings);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!stack.isEmpty()) stack.get(stack.size() - 1).run();
        if (pendingMail != null) {
            final String id = pendingMail;
            pendingMail = null;
            content.postDelayed(() -> { JSONObject ct = find(id); if (ct != null) sendEmail(ct); }, 400);
        }
    }

    void open(Runnable r) { stack.add(r); r.run(); }
    void refresh() { if (!stack.isEmpty()) stack.get(stack.size() - 1).run(); }
    void goBack() {
        if (stack.size() > 1) { stack.remove(stack.size() - 1); stack.get(stack.size() - 1).run(); }
        else finish();
    }
    @Override
    public void onBackPressed() { goBack(); }

    void setHeader(String title, String sub, boolean back, String action, Runnable onAction) {
        header.removeAllViews();
        if (back) {
            TextView bk = tv("←", 24, Color.WHITE, true);
            bk.setPadding(dp(2), 0, dp(16), 0);
            bk.setOnClickListener(v -> goBack());
            header.addView(bk);
        } else {
            TextView ic = tv("📝", 24, Color.WHITE, false);
            ic.setPadding(0, 0, dp(12), 0);
            header.addView(ic);
        }
        LinearLayout t = vbox();
        TextView tt = tv(title, 20, Color.WHITE, true);
        tt.setMaxLines(1);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        t.addView(tt);
        if (sub != null) t.addView(tv(sub, 13, 0xFFCFE0FF, false));
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (action != null) {
            TextView a = tv(action, 22, Color.WHITE, false);
            a.setPadding(dp(12), 0, 0, 0);
            a.setOnClickListener(v -> onAction.run());
            header.addView(a);
        }
    }

    void show(View body, String fabText, Runnable fabAction) {
        content.removeAllViews();
        content.addView(body, new FrameLayout.LayoutParams(-1, -1));
        if (fabText != null) {
            fab.setText(fabText);
            fab.setOnClickListener(v -> fabAction.run());
            fab.setVisibility(View.VISIBLE);
        } else fab.setVisibility(View.GONE);
    }

    // ============================ pantalla principal ============================
    void home() {
        setHeader("Contratos", "Amigo Renta · firma en línea", false, "☰", this::mainMenu);
        if (Store.get(this, "senderName", "").isEmpty() && Net.ready(this)) content.post(this::askSender);
        LinearLayout p = vbox();
        List<JSONObject> cs = Store.list(this, "contracts");
        int pend = 0, sig = 0;
        for (JSONObject o : cs) if (o.optString("status").equals("firmado")) sig++; else pend++;
        LinearLayout top = card();
        top.setBackground(round(PRI2, 16));
        LinearLayout nums = hbox();
        nums.addView(bigNum("⏳ Por firmar", String.valueOf(pend), Color.WHITE), new LinearLayout.LayoutParams(0, -2, 1f));
        nums.addView(bigNum("✅ Firmados", String.valueOf(sig), Color.WHITE), new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(nums);
        p.addView(top);
        LinearLayout ch = hbox();
        ch.setPadding(dp(12), dp(4), dp(12), dp(4));
        for (String f : new String[]{"Todos", "Por firmar", "Firmados"}) ch.addView(chip(f, f.equals(filter), v -> { filter = f; refresh(); }));
        TextView up = tv("🔄 Actualizar", 14, PRI2, true);
        up.setPadding(dp(10), dp(8), dp(4), dp(8));
        up.setOnClickListener(v -> check(true));
        LinearLayout bar = hbox();
        bar.addView(hscroll(ch), new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(up);
        p.addView(bar);
        List<JSONObject> shown = new ArrayList<>();
        for (JSONObject o : cs) {
            boolean ok = o.optString("status").equals("firmado");
            if (filter.equals("Todos") || (filter.equals("Firmados") == ok)) shown.add(o);
        }
        if (cs.isEmpty()) p.addView(empty("Todavía no has enviado contratos.\nToca «＋ Enviar contrato» y elige el PDF que ya llenaste."));
        else if (shown.isEmpty()) p.addView(empty("No hay contratos en este filtro."));
        else {
            LinearLayout l = card();
            for (JSONObject o : shown) {
                if (l.getChildCount() > 0) l.addView(divider());
                boolean ok = o.optString("status").equals("firmado");
                LinearLayout row = hbox();
                row.setPadding(0, dp(6), 0, dp(6));
                row.addView(avatar(o.optString("name"), ok ? GRN : ORG, 42));
                LinearLayout tx = vbox();
                tx.setPadding(dp(12), 0, 0, 0);
                tx.addView(tv(o.optString("name", "—"), 16, TXT, true));
                tx.addView(tv(o.optString("title"), 13, MUT, false));
                tx.addView(tv(ok ? "✅ Firmado el " + nice(o.optString("signedAt")) : "⏳ Enviado el " + nice(o.optString("created")), 13, ok ? GRN : YEL, true));
                if (!o.optString("sender").isEmpty()) tx.addView(tv("📤 Enviado por " + o.optString("sender"), 12, MUT, false));
                row.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
                row.addView(tv("›", 22, MUT, false));
                row.setOnClickListener(v -> menu(o));
                l.addView(row);
            }
            p.addView(l);
        }
        TextView info = tv("La app revisa sola cada 30 minutos y te avisa cuando alguien firma. Los PDF firmados se guardan en Descargas → Amigo Renta Contratos.", 12, MUT, false);
        info.setPadding(dp(18), dp(10), dp(18), dp(90));
        p.addView(info);
        show(scroll(p), "＋  Enviar contrato", this::pickPdf);
        if (System.currentTimeMillis() - lastCheck > 60000) check(false);
    }

    View bigNum(String label, String value, int color) {
        LinearLayout b = vbox();
        b.addView(tv(label, 13, 0xFFDCE8FF, true));
        b.addView(tv(value, 30, color, true));
        return b;
    }

    String nice(String iso) {
        try {
            java.text.SimpleDateFormat in = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            in.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return Store.dateTime(in.parse(iso.length() > 19 ? iso.substring(0, 19) : iso).getTime());
        } catch (Exception e) { return iso; }
    }

    JSONObject find(String id) {
        for (JSONObject o : Store.list(this, "contracts")) if (o.optString("id").equals(id)) return o;
        return null;
    }

    void check(boolean manual) {
        if (!Net.ready(this)) { if (manual) toast("Configura el servidor en ⚙️ Ajustes"); return; }
        lastCheck = System.currentTimeMillis();
        new Thread(() -> {
            String e = Sync.refresh(this);
            runOnUiThread(() -> {
                if (manual) toast(e == null ? "Actualizado ✅" : e);
                if (e == null) refresh();
            });
        }).start();
    }

    // ============================ nuevo contrato ============================
    void pickPdf() {
        if (!Net.ready(this)) { toast("Primero configura el servidor"); open(this::settings); return; }
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        try { startActivityForResult(i, REQ_PDF); } catch (Exception e) { toast("No se pudo abrir el selector de archivos"); }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (rq == REQ_RESTORE) { if (rs == RESULT_OK && data != null && data.getData() != null) Respaldo.restore(this, data.getData()); return; }
        if (rq != REQ_PDF || rs != RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream is = getContentResolver().openInputStream(data.getData())) { cPdf = Net.readAll(is); }
        catch (Exception e) { toast("No pude leer el PDF"); return; }
        if (cPdf.length > 20 * 1024 * 1024) { toast("El PDF es muy grande (máximo 20 MB)"); return; }
        if (cPdf.length < 5 || cPdf[0] != '%' || cPdf[1] != 'P') { toast("Ese archivo no es un PDF"); return; }
        cName = ""; cEmail = ""; cPhone = ""; cTitle = "";
        cFields.clear();
        curPage = 0;
        mode = "signature";
        if (!openRenderer()) { cPdf = null; return; }
        open(this::form);
    }

    void form() {
        if (cPdf == null) { goBack(); return; }
        setHeader("Enviar contrato", "PDF listo (" + (cPdf.length / 1024) + " KB)", true, null, null);
        LinearLayout p = vbox();
        LinearLayout c = card();
        List<JSONObject> cl = Store.list(this, "clients");
        if (!cl.isEmpty()) {
            TextView pick = field("👥  Elegir un cliente anterior");
            pick.setOnClickListener(v -> {
                String[] names = new String[cl.size()];
                for (int i = 0; i < cl.size(); i++) names[i] = cl.get(i).optString("name") + " · " + cl.get(i).optString("email");
                new AlertDialog.Builder(this).setTitle("Clientes anteriores").setItems(names, (d, w) -> {
                    JSONObject k = cl.get(w);
                    cName = k.optString("name");
                    cEmail = k.optString("email");
                    cPhone = k.optString("phone");
                    if (cTitle.isEmpty()) cTitle = "Contrato de renta - " + cName;
                    refresh();
                }).show();
            });
            c.addView(pick);
        }
        EditText nm = input("Nombre completo de quien firma", TXT_CAP);
        nm.setText(cName);
        EditText em = input("correo@ejemplo.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        em.setText(cEmail);
        EditText ph = input("+1 604 555 1111", InputType.TYPE_CLASS_PHONE);
        ph.setText(cPhone);
        EditText ti = input("Ej. Contrato de renta - Juan Pérez - 801 E Broadway #3", TXT_CAP);
        ti.setText(cTitle);
        watch(nm, () -> cName = nm.getText().toString());
        watch(em, () -> cEmail = em.getText().toString());
        watch(ph, () -> cPhone = ph.getText().toString());
        watch(ti, () -> cTitle = ti.getText().toString());
        c.addView(label("👤", "Nombre de quien firma", true));
        c.addView(nm);
        c.addView(label("📧", "Correo", true));
        c.addView(em);
        c.addView(label("📲", "WhatsApp (opcional)", false));
        c.addView(ph);
        c.addView(label("📄", "Nombre del contrato", false));
        c.addView(ti);
        p.addView(c);
        p.addView(button("Siguiente: marcar dónde firma  ›", PRI2, v -> {
            String n = nm.getText().toString().trim(), e = em.getText().toString().trim();
            if (n.length() < 3) { toast("Escribe el nombre de quien firma"); return; }
            if (!e.contains("@") || !e.contains(".")) { toast("Escribe un correo válido"); return; }
            cName = n;
            cEmail = e;
            cPhone = ph.getText().toString().trim();
            String t = ti.getText().toString().trim();
            cTitle = t.isEmpty() ? "Contrato de renta - " + n : t;
            open(this::placeScreen);
        }));
        TextView info = tv("En el siguiente paso tocas en el contrato los lugares donde el cliente debe firmar y poner sus iniciales.", 13, MUT, false);
        info.setPadding(dp(18), dp(10), dp(18), 0);
        p.addView(info);
        show(scroll(p), null, null);
    }

    void watch(EditText e, Runnable r) {
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable s) { r.run(); }
        });
    }

    void upload(String name, String email, String phone, String title) {
        HashMap<String, String> h = new HashMap<>();
        h.put("X-Title", Uri.encode(title));
        h.put("X-Name", Uri.encode(name));
        h.put("X-Email", Uri.encode(email));
        String sender = Store.get(this, "senderName", "").trim();
        h.put("X-Phone", Uri.encode(phone + (sender.isEmpty() ? "" : "|de:" + sender)));
        JSONArray fa = new JSONArray();
        for (JSONObject f : cFields) {
            JSONObject o = new JSONObject();
            Store.put(o, "page", f.optInt("page"));
            Store.put(o, "type", f.optString("type"));
            for (String k : new String[]{"x", "y", "w", "h"}) Store.put(o, k, Math.round(f.optDouble(k) * 10000) / 10000.0);
            fa.put(o);
        }
        h.put("X-Fields", Uri.encode(fa.toString()));
        AlertDialog wait = new AlertDialog.Builder(this).setMessage("Subiendo el contrato…").setCancelable(false).show();
        Net.call(this, "POST", "/contracts", cPdf, "application/pdf", h, (code, body, error) -> {
            wait.dismiss();
            if (error != null || code != 200) {
                new AlertDialog.Builder(this).setTitle("No se pudo subir").setMessage(Net.errorOf(code, body, error)).setPositiveButton("OK", null).show();
                return;
            }
            try {
                JSONObject r = new JSONObject(Net.text(body));
                JSONObject ct = r.getJSONObject("contract");
                Store.put(ct, "url", r.optString("url"));
                Sync.splitSender(ct);
                Store.put(ct, "phone", phone);
                List<JSONObject> cs = Store.list(this, "contracts");
                cs.add(0, ct);
                Store.save(this, "contracts", cs);
                rememberClient(name, email, phone);
                cPdf = null;
                closeRenderer();
                cFields.clear();
                stack.clear();
                open(this::home);
                toast("Contrato listo para firmar ✅");
                sendLink(ct);
            } catch (Exception ex) { toast("Respuesta inesperada del servidor"); }
        });
    }

    void rememberClient(String name, String email, String phone) {
        List<JSONObject> cl = Store.list(this, "clients");
        for (int i = cl.size() - 1; i >= 0; i--) if (cl.get(i).optString("email").equalsIgnoreCase(email)) cl.remove(i);
        JSONObject k = new JSONObject();
        Store.put(k, "name", name);
        Store.put(k, "email", email);
        Store.put(k, "phone", phone);
        cl.add(0, k);
        while (cl.size() > 200) cl.remove(cl.size() - 1);
        Store.save(this, "clients", cl);
    }

    // ============================ enviar enlace ============================
    String msg(JSONObject ct) {
        String first = ct.optString("name").trim().split("\\s+")[0];
        return "Hola " + first + ", te escribimos de Amigo Renta. Aquí está tu contrato para revisarlo y firmarlo en línea (" + ct.optString("title") + "):\n\n"
                + ct.optString("url") + "\n\nSolo abre el enlace, lee el contrato, escribe tu nombre y firma con el dedo. Al terminar puedes descargar tu copia firmada. ¡Gracias!";
    }

    void sendLink(JSONObject ct) {
        boolean wa = !ct.optString("phone").replaceAll("[^0-9]", "").isEmpty();
        List<String> o = new ArrayList<>();
        o.add("📧 Por correo");
        if (wa) { o.add("📲 Por WhatsApp"); o.add("📧 + 📲 Las dos"); }
        o.add("📋 Copiar el enlace");
        new AlertDialog.Builder(this).setTitle("¿Cómo le envío el enlace para firmar?").setItems(o.toArray(new String[0]), (d, w) -> {
            String s = o.get(w);
            if (s.startsWith("📋")) copy(ct.optString("url"));
            else if (s.startsWith("📲")) launch(Store.waIntent(this, ct.optString("phone"), msg(ct)));
            else if (s.startsWith("📧 +")) { pendingMail = ct.optString("id"); launch(Store.waIntent(this, ct.optString("phone"), msg(ct))); }
            else sendEmail(ct);
        }).setNegativeButton("Después", null).show();
    }

    static final String OUTLOOK = "com.microsoft.office.outlook";

    /** Recordatorio: el correo sale de la cuenta elegida en la app de correo (debe ser info@amigorenta.com). */
    void fromHint() {
        String from = Store.get(this, "fromEmail", "info@amigorenta.com");
        if (from.isEmpty()) return;
        Toast.makeText(this, "📧 Revisa que en «De» diga " + from, Toast.LENGTH_LONG).show();
    }

    void sendEmail(JSONObject ct) {
        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
        i.putExtra(Intent.EXTRA_EMAIL, new String[]{ct.optString("email")});
        i.putExtra(Intent.EXTRA_SUBJECT, "Contrato para firmar · Amigo Renta");
        i.putExtra(Intent.EXTRA_TEXT, msg(ct));
        if (Store.installed(this, OUTLOOK)) i.setPackage(OUTLOOK);
        fromHint();
        try { startActivity(i); } catch (Exception e) {
            Intent j = new Intent(Intent.ACTION_SEND);
            j.setType("text/plain");
            j.putExtra(Intent.EXTRA_EMAIL, new String[]{ct.optString("email")});
            j.putExtra(Intent.EXTRA_SUBJECT, "Contrato para firmar · Amigo Renta");
            j.putExtra(Intent.EXTRA_TEXT, msg(ct));
            launch(Intent.createChooser(j, "Enviar por correo"));
        }
    }

    void copy(String s) {
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("enlace", s));
        toast("Enlace copiado");
    }

    // ============================ opciones de un contrato ============================
    interface UriCb { void on(Uri u); }

    void menu(JSONObject ct) {
        boolean ok = ct.optString("status").equals("firmado");
        List<String> o = new ArrayList<>();
        if (ok) {
            o.add("📄 Abrir el contrato firmado");
            o.add("🏢 Enviar copia firmada a la oficina");
            o.add("👤 Enviar copia firmada al cliente");
            o.add("🔎 Ver datos de la firma");
        } else {
            o.add("📤 Reenviar el enlace para firmar");
            o.add("📋 Copiar el enlace");
            o.add("👀 Ver el contrato enviado");
        }
        o.add(ok ? "🗑️ Borrar del servidor" : "❌ Cancelar este contrato");
        new AlertDialog.Builder(this).setTitle(ct.optString("name")).setItems(o.toArray(new String[0]), (d, w) -> {
            String s = o.get(w);
            if (s.startsWith("📄")) withSigned(ct, u -> {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(u, "application/pdf");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                launch(i);
            });
            else if (s.startsWith("🏢")) withSigned(ct, u -> mailSigned(ct, u, Store.get(this, "officeEmail", "")));
            else if (s.startsWith("👤")) withSigned(ct, u -> {
                String[] w2 = {"📧 Por correo", "📲 Por WhatsApp"};
                new AlertDialog.Builder(this).setItems(w2, (d2, k) -> {
                    if (k == 0) mailSigned(ct, u, ct.optString("email"));
                    else if (ct.optString("phone").replaceAll("[^0-9]", "").isEmpty()) toast("No tiene WhatsApp guardado");
                    else waFile(ct.optString("phone"), "Hola, te enviamos tu contrato firmado. ¡Gracias! — Amigo Renta", u);
                }).show();
            });
            else if (s.startsWith("🔎")) new AlertDialog.Builder(this).setTitle("Datos de la firma")
                    .setMessage("Firmó: " + ct.optString("signer") + "\nCorreo: " + ct.optString("email") + "\nFecha: " + nice(ct.optString("signedAt"))
                            + "\nIP: " + ct.optString("ip") + (ct.optString("country").isEmpty() ? "" : " (" + ct.optString("country") + ")")
                            + "\nDispositivo: " + ct.optString("ua") + "\n\nID: " + ct.optString("id")
                            + "\n\nEl PDF firmado incluye al final una página con este certificado.")
                    .setPositiveButton("OK", null).show();
            else if (s.startsWith("📤")) sendLink(ct);
            else if (s.startsWith("📋")) copy(ct.optString("url"));
            else if (s.startsWith("👀")) launch(new Intent(Intent.ACTION_VIEW, Uri.parse(ct.optString("url") + "/original.pdf")));
            else new AlertDialog.Builder(this).setTitle(ok ? "¿Borrar del servidor?" : "¿Cancelar este contrato?")
                        .setMessage(ok ? "Se borra del servidor y de esta lista. La copia en Descargas → Amigo Renta Contratos se queda." : "El enlace deja de funcionar y el cliente ya no podrá firmarlo.")
                        .setPositiveButton(ok ? "Borrar" : "Cancelar contrato", (d2, k) -> Net.call(this, "DELETE", "/contracts/" + ct.optString("id"), null, null, null, (code, body, error) -> {
                            if (error != null || code != 200) { toast(Net.errorOf(code, body, error)); return; }
                            List<JSONObject> cs = Store.list(this, "contracts");
                            for (int i = cs.size() - 1; i >= 0; i--) if (cs.get(i).optString("id").equals(ct.optString("id"))) cs.remove(i);
                            Store.save(this, "contracts", cs);
                            refresh();
                        })).setNegativeButton("No", null).show();
        }).show();
    }

    void withSigned(JSONObject ct, UriCb cb) {
        String local = ct.optString("localSigned");
        if (!local.isEmpty()) {
            try (InputStream is = getContentResolver().openInputStream(Uri.parse(local))) { if (is != null) { cb.on(Uri.parse(local)); return; } } catch (Exception e) { }
        }
        AlertDialog wait = new AlertDialog.Builder(this).setMessage("Descargando el contrato firmado…").setCancelable(false).show();
        new Thread(() -> {
            Uri u = Sync.download(this, ct);
            if (u != null) {
                List<JSONObject> cs = Store.list(this, "contracts");
                for (JSONObject o : cs) if (o.optString("id").equals(ct.optString("id"))) Store.put(o, "localSigned", u.toString());
                Store.save(this, "contracts", cs);
            }
            runOnUiThread(() -> { wait.dismiss(); if (u == null) toast("No se pudo descargar el contrato firmado"); else cb.on(u); });
        }).start();
    }

    void mailSigned(JSONObject ct, Uri u, String to) {
        if (!to.contains("@")) { toast("Escribe el correo de la oficina en ⚙️ Ajustes"); open(this::settings); return; }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
        i.putExtra(Intent.EXTRA_SUBJECT, "Contrato firmado · " + ct.optString("title"));
        i.putExtra(Intent.EXTRA_TEXT, "Contrato firmado electrónicamente por " + ct.optString("signer", ct.optString("name")) + " el " + nice(ct.optString("signedAt")) + ".\n\n— Amigo Renta");
        i.putExtra(Intent.EXTRA_STREAM, u);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        fromHint();
        if (Store.installed(this, OUTLOOK)) { i.setPackage(OUTLOOK); try { startActivity(i); return; } catch (Exception ignored) { i.setPackage(null); } }
        launch(Intent.createChooser(i, "Enviar contrato firmado"));
    }

    void waFile(String phone, String text, Uri file) {
        String pkg = Store.waPkg(this);
        if (pkg != null) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setPackage(pkg);
            i.putExtra("jid", Store.digits(phone) + "@s.whatsapp.net");
            i.putExtra(Intent.EXTRA_TEXT, text);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_STREAM, file);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try { startActivity(i); return; } catch (Exception ignored) { }
        }
        toast("No se encontró WhatsApp");
    }

    // ============================ marcar firmas e iniciales ============================
    boolean openRenderer() {
        closeRenderer();
        try {
            File f = new File(getCacheDir(), "contrato.pdf");
            try (FileOutputStream os = new FileOutputStream(f)) { os.write(cPdf); }
            pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(pfd);
            nPages = renderer.getPageCount();
            return nPages > 0;
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("No pude abrir el PDF")
                    .setMessage("Puede que esté protegido con contraseña o dañado. Guárdalo de nuevo como PDF sin protección e inténtalo otra vez.")
                    .setPositiveButton("OK", null).show();
            closeRenderer();
            return false;
        }
    }

    void closeRenderer() {
        try { if (renderer != null) renderer.close(); } catch (Exception e) { }
        try { if (pfd != null) pfd.close(); } catch (Exception e) { }
        renderer = null;
        pfd = null;
    }

    @Override
    protected void onDestroy() { closeRenderer(); super.onDestroy(); }

    int count(String type) {
        int n = 0;
        for (JSONObject f : cFields) if (f.optString("type").equals(type)) n++;
        return n;
    }

    void placeScreen() {
        if (cPdf == null || (renderer == null && !openRenderer())) { goBack(); return; }
        if (curPage >= nPages) curPage = nPages - 1;
        setHeader("Marcar dónde firma", "Página " + (curPage + 1) + " de " + nPages, true, null, null);
        LinearLayout p = vbox();

        LinearLayout tools = hbox();
        tools.setPadding(dp(12), dp(8), dp(12), dp(2));
        tools.addView(chip("✍️ Firma", mode.equals("signature"), v -> { mode = "signature"; refresh(); }));
        tools.addView(chip("🔤 Iniciales", mode.equals("initials"), v -> { mode = "initials"; refresh(); }));
        tools.addView(chip("👤 Nombre completo", mode.equals("name"), v -> { mode = "name"; refresh(); }));
        p.addView(hscroll(tools));
        TextView hint = tv((mode.equals("signature") ? "Toca en la página donde debe FIRMAR." : mode.equals("name") ? "Toca en la página donde debe ir su NOMBRE COMPLETO." : "Toca en la página donde debe poner sus INICIALES.")
                + " Toca un recuadro para quitarlo o cambiar su tamaño.", 13, MUT, false);
        hint.setPadding(dp(16), dp(2), dp(16), dp(8));
        p.addView(hint);

        // página
        int availW = getResources().getDisplayMetrics().widthPixels - dp(24);
        PdfRenderer.Page pg = renderer.openPage(curPage);
        float pw = pg.getWidth(), ph = pg.getHeight();
        int bw = Math.min(availW, 1400), bh = Math.round(bw * ph / pw);
        Bitmap bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        new Canvas(bmp).drawColor(Color.WHITE);
        pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        pg.close();
        final int vw = availW, vh = Math.round(availW * ph / pw);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.WHITE);
        frame.setElevation(dp(2));
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(bmp);
        iv.setScaleType(ImageView.ScaleType.FIT_XY);
        frame.addView(iv, new FrameLayout.LayoutParams(vw, vh));
        final float[] touch = new float[2];
        iv.setOnTouchListener((v, e) -> { touch[0] = e.getX(); touch[1] = e.getY(); return false; });
        iv.setOnClickListener(v -> addField(touch[0] / vw, touch[1] / vh));
        for (JSONObject f : cFields) {
            if (f.optInt("page") != curPage) continue;
            String ty = f.optString("type");
            boolean ini = ty.equals("initials"), nmf = ty.equals("name");
            TextView box = tv(ini ? "Iniciales" : nmf ? "👤 Nombre" : "✍️ Firma", ini ? 10 : 12, ini ? 0xFF1E40AF : nmf ? 0xFF166534 : 0xFF92400E, true);
            box.setGravity(Gravity.CENTER);
            box.setBackground(roundStroke(ini ? 0xCCDBEAFE : nmf ? 0xCCDCFCE7 : 0xCCFEF3C7, 6, ini ? 0xFF2563EB : nmf ? 0xFF16A34A : 0xFFF59E0B));
            FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(Math.max(dp(24), Math.round((float) f.optDouble("w") * vw)), Math.max(dp(16), Math.round((float) f.optDouble("h") * vh)));
            bl.leftMargin = Math.round((float) f.optDouble("x") * vw);
            bl.topMargin = Math.round((float) f.optDouble("y") * vh);
            box.setOnClickListener(v -> fieldMenu(f));
            frame.addView(box, bl);
        }
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(vw, vh);
        fl.setMargins(dp(12), 0, dp(12), dp(8));
        p.addView(frame, fl);

        // navegación de páginas
        LinearLayout nav = hbox();
        nav.setPadding(dp(8), 0, dp(8), 0);
        nav.addView(outline("‹  Anterior", curPage > 0 ? PRI2 : BRD, v -> { if (curPage > 0) { curPage--; refresh(); } }), weightLp(1f));
        nav.addView(outline("Siguiente  ›", curPage < nPages - 1 ? PRI2 : BRD, v -> { if (curPage < nPages - 1) { curPage++; refresh(); } }), weightLp(1f));
        p.addView(nav);
        LinearLayout more = hbox();
        more.setPadding(dp(8), dp(6), dp(8), 0);
        more.addView(outline("🔤 Iniciales en todas las páginas", 0xFF2563EB, v -> initialsAllPages()), weightLp(1f));
        p.addView(more);

        LinearLayout sum = card();
        sum.addView(tv("✍️ Firmas: " + count("signature") + "   🔤 Iniciales: " + count("initials") + "   👤 Nombre: " + count("name"), 15, TXT, true));
        sum.addView(tv("Para: " + cName + " · " + cEmail, 13, MUT, false));
        p.addView(sum);
        p.addView(button("📤  Subir y enviar para firmar", GRN, v -> {
            if (count("signature") == 0) { toast("Marca al menos un lugar de FIRMA"); return; }
            upload(cName, cEmail, cPhone, cTitle);
        }));
        TextView sp = tv("", 6, MUT, false);
        sp.setPadding(0, 0, 0, dp(30));
        p.addView(sp);
        show(scroll(p), null, null);
    }

    void addField(float x, float y) {
        boolean ini = mode.equals("initials"), nmf = mode.equals("name");
        double w = ini ? 0.11 : nmf ? 0.34 : 0.32, h = ini ? 0.045 : nmf ? 0.035 : 0.06;
        JSONObject f = new JSONObject();
        Store.put(f, "page", curPage);
        Store.put(f, "type", mode);
        Store.put(f, "w", w);
        Store.put(f, "h", h);
        Store.put(f, "x", Math.max(0, Math.min(1 - w, x - w / 2)));
        Store.put(f, "y", Math.max(0, Math.min(1 - h, y - h / 2)));
        cFields.add(f);
        refresh();
    }

    void fieldMenu(JSONObject f) {
        String[] o = {"➕ Más grande", "➖ Más pequeño", "🗑️ Quitar"};
        new AlertDialog.Builder(this).setTitle(f.optString("type").equals("initials") ? "Iniciales" : f.optString("type").equals("name") ? "Nombre completo" : "Firma").setItems(o, (d, w) -> {
            if (w == 2) { cFields.remove(f); refresh(); return; }
            double k = w == 0 ? 1.25 : 0.8;
            double cx = f.optDouble("x") + f.optDouble("w") / 2, cy = f.optDouble("y") + f.optDouble("h") / 2;
            double nw = Math.max(0.04, Math.min(0.9, f.optDouble("w") * k)), nh = Math.max(0.02, Math.min(0.3, f.optDouble("h") * k));
            Store.put(f, "w", nw);
            Store.put(f, "h", nh);
            Store.put(f, "x", Math.max(0, Math.min(1 - nw, cx - nw / 2)));
            Store.put(f, "y", Math.max(0, Math.min(1 - nh, cy - nh / 2)));
            refresh();
        }).show();
    }

    /** Pone iniciales en el mismo lugar en todas las páginas (donde está la última que marcaste, o abajo a la derecha). */
    void initialsAllPages() {
        JSONObject ref = null;
        for (JSONObject f : cFields) if (f.optString("type").equals("initials")) ref = f;
        double w = ref != null ? ref.optDouble("w") : 0.11, h = ref != null ? ref.optDouble("h") : 0.045;
        double x = ref != null ? ref.optDouble("x") : 0.84, y = ref != null ? ref.optDouble("y") : 0.92;
        int added = 0;
        for (int pg = 0; pg < nPages; pg++) {
            boolean has = false;
            for (JSONObject f : cFields) if (f.optInt("page") == pg && f.optString("type").equals("initials")) has = true;
            if (has) continue;
            JSONObject f = new JSONObject();
            Store.put(f, "page", pg);
            Store.put(f, "type", "initials");
            Store.put(f, "x", Math.min(x, 1 - w));
            Store.put(f, "y", Math.min(y, 1 - h));
            Store.put(f, "w", w);
            Store.put(f, "h", h);
            cFields.add(f);
            added++;
        }
        toast(added == 0 ? "Todas las páginas ya tienen iniciales" : "Iniciales agregadas en " + added + " página(s)");
        refresh();
    }

    // ============================ menú, reporte y respaldo ============================
    void mainMenu() {
        String[] o = {"📊 Reporte en Excel", "💾 Copia de seguridad", "⚙️ Ajustes"};
        new AlertDialog.Builder(this).setItems(o, (d, w) -> {
            if (w == 0) excel();
            else if (w == 1) Respaldo.menu(this);
            else open(this::settings);
        }).show();
    }

    void askSender() {
        if (!Store.get(this, "senderName", "").isEmpty()) return;
        EditText e = input("Ej. Daylin", TXT_CAP);
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(e);
        new AlertDialog.Builder(this).setTitle("¿Cómo te llamas?")
                .setMessage("Sale en la lista como «Enviado por…», para saber quién mandó cada contrato.")
                .setView(box)
                .setPositiveButton("Guardar", (d, w) -> { Store.putS(this, "senderName", e.getText().toString().trim()); refresh(); })
                .setNegativeButton("Después", null).show();
    }

    String status(JSONObject o) { return o.optString("status").equals("firmado") ? "Firmado" : "Por firmar"; }

    void excel() {
        if (Build.VERSION.SDK_INT < 29) { toast("Necesita Android 10 o más nuevo"); return; }
        List<JSONObject> cs = Store.list(this, "contracts");
        if (cs.isEmpty()) { toast("Todavía no hay contratos"); return; }
        List<List<Object>> all = new ArrayList<>(), pend = new ArrayList<>(), res = new ArrayList<>();
        all.add(Xlsx.row("Cliente", "Correo", "Teléfono", "Contrato", "Enviado por", "Fecha de envío", "Estado", "Fecha de firma", "Firmó", "IP", "Días para firmar", "Enlace"));
        pend.add(Xlsx.row("Cliente", "Correo", "Teléfono", "Contrato", "Enviado por", "Fecha de envío", "Días esperando", "Enlace"));
        java.util.LinkedHashMap<String, int[]> bySender = new java.util.LinkedHashMap<>();
        int nSig = 0, nPen = 0;
        long now = System.currentTimeMillis();
        for (JSONObject o : cs) {
            boolean ok = o.optString("status").equals("firmado");
            long sent = isoMs(o.optString("created")), signed = isoMs(o.optString("signedAt"));
            String who = o.optString("sender").isEmpty() ? "—" : o.optString("sender");
            all.add(Xlsx.row(o.optString("name"), o.optString("email"), o.optString("phone"), o.optString("title"), who, excelDate(sent), status(o),
                    ok ? excelDate(signed) : "", o.optString("signer"), o.optString("ip"), ok && sent > 0 && signed > 0 ? Math.max(0, Math.round((signed - sent) / 86400000.0)) : "",
                    o.optString("url")));
            if (!ok) pend.add(Xlsx.row(o.optString("name"), o.optString("email"), o.optString("phone"), o.optString("title"), who, excelDate(sent),
                    sent > 0 ? Math.round((now - sent) / 86400000.0) : "", o.optString("url")));
            if (ok) nSig++; else nPen++;
            int[] k = bySender.get(who);
            if (k == null) { k = new int[2]; bySender.put(who, k); }
            k[ok ? 0 : 1]++;
        }
        res.add(Xlsx.row("Resumen", "Cantidad"));
        res.add(Xlsx.row("Contratos enviados", cs.size()));
        res.add(Xlsx.row("Firmados", nSig));
        res.add(Xlsx.row("Por firmar", nPen));
        res.add(Xlsx.row("", ""));
        res.add(Xlsx.row("Enviado por", "Firmados", "Por firmar"));
        for (java.util.Map.Entry<String, int[]> e : bySender.entrySet()) res.add(Xlsx.row(e.getKey(), e.getValue()[0], e.getValue()[1]));
        res.add(Xlsx.row("", ""));
        res.add(Xlsx.row("Reporte generado", Store.dateTime(now)));
        List<String> names = new ArrayList<>();
        names.add("Contratos"); names.add("Por firmar"); names.add("Resumen");
        List<List<List<Object>>> sheets = new ArrayList<>();
        sheets.add(all); sheets.add(pend); sheets.add(res);
        List<int[]> widths = new ArrayList<>();
        widths.add(new int[]{26, 28, 16, 38, 16, 18, 12, 18, 24, 16, 10, 50});
        widths.add(new int[]{26, 28, 16, 38, 16, 18, 12, 50});
        widths.add(new int[]{26, 18, 14});
        try {
            android.content.ContentValues cv = new android.content.ContentValues();
            String day = new java.text.SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(new java.util.Date());
            cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "Contratos_" + day + ".xlsx");
            cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Reportes");
            Uri u = getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) throw new Exception("sin archivo");
            try (java.io.OutputStream os = getContentResolver().openOutputStream(u)) { Xlsx.writeBook(os, names, sheets, widths); }
            new AlertDialog.Builder(this).setTitle("📊 Reporte listo")
                    .setMessage(cs.size() + " contratos (" + nSig + " firmados, " + nPen + " por firmar).\n\nSe guardó en Descargas → Amigo Renta Reportes.")
                    .setPositiveButton("Abrir", (d, w) -> {
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setDataAndType(u, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        launch(i);
                    })
                    .setNeutralButton("Enviar", (d, w) -> {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                        i.putExtra(Intent.EXTRA_STREAM, u);
                        i.putExtra(Intent.EXTRA_SUBJECT, "Reporte de contratos · Amigo Renta");
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        launch(Intent.createChooser(i, "Enviar reporte"));
                    })
                    .setNegativeButton("Listo", null).show();
        } catch (Exception e) { toast("No se pudo crear el Excel"); }
    }

    long isoMs(String iso) {
        try {
            java.text.SimpleDateFormat in = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            in.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return in.parse(iso.length() > 19 ? iso.substring(0, 19) : iso).getTime();
        } catch (Exception e) { return 0; }
    }

    String excelDate(long ms) {
        if (ms <= 0) return "";
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        f.setTimeZone(Store.TZ);
        return f.format(new java.util.Date(ms));
    }

    // ============================ ajustes ============================
    void settings() {
        setHeader("Ajustes", null, stack.size() > 1, null, null);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(tv("🔗  Servidor de Amigo Renta", 16, TXT, true));
        EditText srv = input("https://amigo-renta-contratos.xxxx.workers.dev", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        srv.setText(Store.get(this, "serverUrl", ""));
        EditText key = input("Clave del dispositivo (DEVICE_KEY)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setText(Store.get(this, "deviceKey", ""));
        c.addView(labeled("Dirección del servidor", srv));
        c.addView(labeled("Clave del dispositivo", key));
        c.addView(tv("Es el servidor de contratos en Cloudflare (amigo-renta-contratos). La clave es la DEVICE_KEY que pusieron ahí.", 12, MUT, false));
        p.addView(c);
        LinearLayout c2 = card();
        c2.addView(tv("🏢  Oficina", 16, TXT, true));
        EditText office = input("Ej. info@amigorenta.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        office.setText(Store.get(this, "officeEmail", ""));
        c2.addView(labeled("Correo para recibir los contratos firmados", office));
        EditText me = input("Ej. Daylin", TXT_CAP);
        me.setText(Store.get(this, "senderName", ""));
        c2.addView(labeled("Tu nombre (sale como «Enviado por…»)", me));
        EditText from = input("info@amigorenta.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        from.setText(Store.get(this, "fromEmail", "info@amigorenta.com"));
        c2.addView(labeled("Correo desde el que se envían los contratos", from));
        c2.addView(tv("En Outlook del teléfono debe estar agregada esa cuenta y elegida como predeterminada. La app abre Outlook directamente.", 12, MUT, false));
        final String[] waOpts = {"WhatsApp Business", "WhatsApp normal"};
        TextView wa = picker(waOpts, Store.get(this, "waApp", "business").equals("business") ? waOpts[0] : waOpts[1]);
        c2.addView(labeled("Abrir WhatsApp con", wa));
        p.addView(c2);
        p.addView(button("Guardar", PRI2, v -> {
            Store.putS(this, "serverUrl", srv.getText().toString().trim());
            Store.putS(this, "deviceKey", key.getText().toString().trim());
            Store.putS(this, "officeEmail", office.getText().toString().trim());
            Store.putS(this, "waApp", ((String) wa.getTag()).equals(waOpts[0]) ? "business" : "normal");
            Store.putS(this, "senderName", me.getText().toString().trim());
            Store.putS(this, "fromEmail", from.getText().toString().trim());
            if (!Net.ready(this)) { toast("Falta la dirección o la clave"); return; }
            AlertDialog w = new AlertDialog.Builder(this).setMessage("Probando la conexión…").setCancelable(false).show();
            Net.call(this, "GET", "/status", null, null, null, (code, body, error) -> {
                w.dismiss();
                if (error != null || code != 200) {
                    new AlertDialog.Builder(this).setTitle("No se pudo conectar").setMessage(Net.errorOf(code, body, error) + "\n\nLos datos quedaron guardados; revísalos.").setPositiveButton("OK", null).show();
                    return;
                }
                toast("Conectado con el servidor ✅");
                stack.clear();
                open(this::home);
            });
        }));
        TextView ver = tv("Contratos Amigo Renta · versión 1.3", 12, MUT, false);
        ver.setPadding(dp(18), dp(14), dp(18), 0);
        p.addView(ver);
        show(scroll(p), null, null);
    }

    // ============================ componentes ============================
    LinearLayout.LayoutParams weightLp(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, w);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    void launch(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrir esto"); }
    }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ============================ Componentes visuales ============================
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable roundStroke(int color, float r, int stroke) {
        GradientDrawable g = round(color, r);
        g.setStroke(dp(1), stroke);
        return g;
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(round(Color.WHITE, 16));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(6), dp(14), dp(6));
        c.setLayoutParams(lp);
        return c;
    }

    ScrollView scroll(LinearLayout inner) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        inner.setPadding(0, dp(6), 0, dp(100));
        s.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        return s;
    }

    HorizontalScrollView hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    View sectionTitle(String t, String link, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(dp(18), dp(16), dp(18), dp(6));
        r.addView(tv(t, 17, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (link != null) {
            TextView k = tv(link, 14, PRI2, true);
            k.setOnClickListener(l);
            r.addView(k);
        }
        return r;
    }

    View empty(String s) {
        TextView t = tv(s, 14, MUT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundStroke(Color.WHITE, 14, BRD));
        t.setPadding(dp(14), dp(20), dp(14), dp(20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(4), dp(14), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    View divider() {
        View d = new View(this);
        d.setBackgroundColor(BRD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(10), 0, dp(10));
        d.setLayoutParams(lp);
        return d;
    }

    View gap(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    TextView chip(String text, boolean sel, View.OnClickListener l) {
        TextView t = tv(text, 14, TXT, true);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        styleChip(t, sel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    void styleChip(TextView t, boolean sel) {
        t.setBackground(sel ? round(PRI2, 20) : roundStroke(Color.WHITE, 20, BRD));
        t.setTextColor(sel ? Color.WHITE : TXT);
    }

    TextView avatar(String n, int color, int size) {
        String ini = n == null || n.trim().isEmpty() ? "?" : n.trim().substring(0, 1).toUpperCase(Store.ES);
        TextView t = tv(ini, size / 2.4f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return t;
    }

    View action(String ic, String label, int fg, int bg, View.OnClickListener l) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(dp(2), dp(12), dp(2), dp(10));
        TextView i = tv(ic, 20, fg, false);
        i.setGravity(Gravity.CENTER);
        TextView t = tv(label, 10, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        t.setEllipsize(TextUtils.TruncateAt.END);
        b.addView(i);
        b.addView(t);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    TextView button(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 16, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, 14));
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    TextView outline(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 15, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 14, color));
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, 0);
        return lp;
    }

    EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFFA0A8B5);
        e.setTextColor(TXT);
        e.setTextSize(15);
        e.setInputType(type);
        if ((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            e.setMinLines(2);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        e.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        e.setPadding(dp(12), dp(11), dp(12), dp(11));
        e.setLayoutParams(fieldLp());
        return e;
    }

    TextView field(String text) {
        TextView t = tv(text, 15, TXT, false);
        t.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setLayoutParams(fieldLp());
        return t;
    }

    TextView picker(String[] opts, String cur) {
        String val = (cur == null || cur.isEmpty()) ? (opts.length > 0 ? opts[0] : "") : cur;
        final TextView t = field(val + "  ▾");
        t.setTag(val);
        t.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(opts, (dlg, w) -> {
            t.setTag(opts[w]);
            t.setText(opts[w] + "  ▾");
        }).show());
        return t;
    }

    View label(String icon, String text, boolean req) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(14), 0, 0);
        r.addView(tv(icon + "  " + text, 13, MUT, true));
        if (req) r.addView(tv(" *", 13, RED, true));
        return r;
    }

    View labeled(String text, View v) {
        LinearLayout b = vbox();
        TextView l = tv(text, 13, MUT, true);
        l.setPadding(0, dp(14), 0, 0);
        b.addView(l);
        b.addView(v);
        return b;
    }

    View twoCols(View a, View b) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.setMargins(dp(6), 0, 0, 0);
        r.addView(a, l1);
        r.addView(b, l2);
        return r;
    }

}
